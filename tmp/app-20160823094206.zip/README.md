# Brushfire

[A Zendesk app to help Brushfire organizations find their customers orders, attendees and groups in Brushfire]


Please submit bug reports to help@brushfiretech.com 

